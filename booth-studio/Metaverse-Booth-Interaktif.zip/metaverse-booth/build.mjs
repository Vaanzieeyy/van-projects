import {build} from 'esbuild';import fs from 'node:fs';
await build({entryPoints:['app.js'],bundle:true,format:'iife',target:'es2022',outfile:'app.bundle.js',minify:true,legalComments:'inline',supported:{'top-level-await':false}}).catch(async e=>{throw e});
let html=fs.readFileSync('index.template.html','utf8');html=html.replace('__FONT__',fs.readFileSync('assets/dm-sans.woff2').toString('base64')).replace('__APP__',()=>fs.readFileSync('app.bundle.js','utf8').replace(/<\/script/gi,'<\\/script'));
fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/index.html',html);
console.log('Built standalone offline HTML:',fs.statSync('dist/index.html').size,'bytes');
